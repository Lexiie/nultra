Strike Alpha Foundry validation
Public, read-only API requests only. No API keys or wallet secrets.
Check summary.json, candle_audit.json, websocket.json and endpoint_results.csv.
Timestamp coverage may be misleading if server ignores startTime/endTime.
